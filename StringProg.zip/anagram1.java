package StringProg;

import java.util.Scanner;

public class anagram1 
{
   public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("enter first input");
    String s1=sc.nextLine();
    char []ch1=s1.toCharArray();
    int c1=0;
    
    System.out.println("enter second input");
    String s2=sc.nextLine();
    char [] ch2=s2.toCharArray();
    int c2=0;
    
    for (int i = 0; i < ch1.length; i++) {
	  c1=c1+ch1[i];
	 
	}
    for (int j = 0; j < ch2.length; j++) {
		c2=c2+ch2[j];
	}
    if(c1==c2) {
    	System.out.println("is anagram");
    }
    else {
    	System.out.println("not an anagram");
    }
}
}
