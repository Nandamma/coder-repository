package StringProg;

import java.util.Scanner;

public class anagram
{
   public static void main(String[] args)
   {
	  Scanner sc=new Scanner(System.in);
	  System.out.println("enter number of inputs");
	  int n=sc.nextInt();

	     for (int i = 1; i <=n; i++)
	     {
		  System.out.println("enter string");
		  String[] s1=sc.nextLine().split(" ");
		 
		  String f=s1[0];
		  char[] ch1=f.toCharArray();
		  int c1=0;
		  
		  String l=s1[s1.length-1];
		  char[] ch2=l.toCharArray();
		  int c2=0;
		 
		  
		  for (int j = 0; j < ch1.length; j++) {
			c1=c1+ch1[j];
		  }
		  for (int k = 0; k < ch2.length; k++) {
			c2=c2+ch2[k];
		}
		  if(c1==c2) {
			  System.out.println("YES");
		  }
		  else {
			  System.out.println("NO");
		  }
      }
    }
}
